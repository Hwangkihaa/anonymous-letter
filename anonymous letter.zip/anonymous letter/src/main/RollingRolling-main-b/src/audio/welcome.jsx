import React from 'react';
import WelcomePage_Audio from '../audio/welcome_page.mp3';
import { useEffect } from 'react';


export function WelcomeAudio() {
  let welcome_audio = new Audio(WelcomePage_Audio)
  
  useEffect(() => {
    const handleKeyDown = (e) => {
      // 키보드 이벤트 처리
      if (e.keyCode === 113) {
        // f2 키가 눌렸을 때 처리
        welcome_audio.play()
      };
    }
    window.addEventListener('keydown', handleKeyDown);
    return () => {
      window.removeEventListener('keydown', handleKeyDown);
    };
  }, []);

  return (
   <div>
      </div>
  )
}


export default WelcomeAudio;

