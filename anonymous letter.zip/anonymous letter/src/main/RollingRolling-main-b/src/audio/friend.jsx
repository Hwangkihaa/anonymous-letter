import React from 'react';
import FriendPage_Audio from './friend_page.mp3';
import { useEffect } from 'react';


export function FriendAudio() {
  let friend_audio = new Audio(FriendPage_Audio)

  const friend = () => {
    friend_audio.play()
  }

  useEffect(() => {
    const handleKeyDown = (e) => {
      // 키보드 이벤트 처리
      if (e.keyCode === 113) {
        // f2 키가 눌렸을 때 처리
        friend_audio.play()
      };
    }

    window.addEventListener('keydown', handleKeyDown);
    return () => {
      window.removeEventListener('keydown', handleKeyDown);
    };
  }, []);


  return (
  <div>
  </div>
  )
}

export default FriendAudio;