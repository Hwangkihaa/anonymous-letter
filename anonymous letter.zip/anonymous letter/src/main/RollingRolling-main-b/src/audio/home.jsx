import React from 'react';
import HomePage_Audio from '../audio/home_page.mp3';
import { useEffect } from 'react';

export function HomeAudio() {
    let home_audio = new Audio(HomePage_Audio)

    const home = () => {
        home_audio.play()
    }

    useEffect(() => {
        const handleKeyDown = (e) => {
            // 키보드 이벤트 처리
            if (e.keyCode === 113) {
                // f2 키가 눌렸을 때 처리
                home_audio.play()
            };
        }

        window.addEventListener('keydown', handleKeyDown);
        return () => {
            window.removeEventListener('keydown', handleKeyDown);
        };
    }, []);

    return (
    <div>
    </div>
    )
}

export default HomeAudio;