import React from 'react';
import SignupPage_Audio from '../audio/signup_page.mp3';
import { useEffect } from 'react';

export function SignupAudio() {
  let signup_audio = new Audio(SignupPage_Audio)

  const signup = () => {
    signup_audio.play()
  }

  useEffect(() => {
    const handleKeyDown = (e) => {
      // 키보드 이벤트 처리
      if (e.keyCode === 113) {
        // f2 키가 눌렸을 때 처리
        signup_audio.play()
      };
    }

    window.addEventListener('keydown', handleKeyDown);
    return () => {
      window.removeEventListener('keydown', handleKeyDown);
    };
  }, []);

  return (
 <div>
    </div>
  )
}

export default SignupAudio;