import React from 'react';
import MyPage_Audio from './my_page.mp3';
import { useEffect } from 'react';


export function MyAudio() {
  let my_audio = new Audio(MyPage_Audio)

  const my = () => {
    my_audio.play()
  }

  useEffect(() => {
    const handleKeyDown = (e) => {
      // 키보드 이벤트 처리
      if (e.keyCode === 113) {
        // f2 키가 눌렸을 때 처리
        my_audio.play()
      };
    }

    window.addEventListener('keydown', handleKeyDown);
    return () => {
      window.removeEventListener('keydown', handleKeyDown);
    };
  }, []);


  return (
 <div>
    </div>
  )
}

export default MyAudio;