import React from 'react';
import MyQuestion from './components/MyQuestion';
import {
  WriteQuestionContainer,
  QuestionContainer,
  EmptyQuestion,
} from './DetailWriteQuestion';
import QuestionBoxs from './components/QuestionBoxs';
import MyAudio from '../../audio/my';
import styled from 'styled-components';
import { useNavigate } from 'react-router-dom';
import Button from '../elements/Button';
import StudyImage from '../../style/img/star.png';

function DetailMyQuestion({ data }) {

  const navigate = useNavigate();

    function handleClick(){
      navigate('/home/answerstudy');
    }

  return (
    <WriteQuestionContainer>
        <MyAudioContainer>
            <MyAudio />
        </MyAudioContainer>
        <ButtonContainer>
           <StyledButton onClick={handleClick}>
           <img src={StudyImage} alt="편지 답변 도움말" />
           </StyledButton>
        </ButtonContainer>
      <QuestionContainer>
        {data.upperPost.length !== 0 ? (
          <label>새 질문</label>
        ) : (
          <label>
            <EmptyQuestion>새로운 질문이 존재하지 않습니다.</EmptyQuestion>
          </label>
        )}

        {data.upperPost.map((list) => {
          return (
            <MyQuestion
              key={list.postId}
              nickname={list.nickname}
              content={list.content}
              date={list.createdAt}
              postId={list.postId}
            />
          );
        })}
      </QuestionContainer>

      <QuestionContainer>
        {data.bottomPost.content.length !== 0 ? (
          <label>답변완료</label>
        ) : (
          <label>
            <EmptyQuestion>아직 완료된 답변이 존재하지 않습니다.</EmptyQuestion>
          </label>
        )}
        {data.bottomPost.content.map((list) => (
          <QuestionBoxs
            key={list.postId}
            nickname={list.nickname}
            content={list.content}
            date={list.createdAt}
            postId={list.postId}
            comment={list.commentResponseDto}
          />
        ))}
      </QuestionContainer>
    </WriteQuestionContainer>
  );
}

const MyAudioContainer = styled.div`
  position : relative;
  float : right;
  top: 20px;
  right: 30px;
`;

// 버튼 컨테이너 스타일
const ButtonContainer = styled.div`
  position: absolute;
  bottom: 20px; /* 하단 여백 설정 */
  right: 10px; /* 오른쪽 여백 설정 */
`;

// 스타일링된 버튼
const StyledButton = styled(Button)`
  padding: 20px; /* 버튼 안의 패딩 */
  display: flex;
  align-items: center;
  justify-content: center;
  cursor: pointer; /* 마우스 커서를 포인터로 변경 */
  background-color: transparent; /* 배경색을 투명하게 설정 */
  border: none; /* 테두리 제거 */
  transform: none; /* 호버 시 버튼의 움직임을 없앰 */

  img {
    width: 60px; /* 이미지 너비 */
    height: 60px; /* 이미지 높이 */
  }

  &:hover {
    transform: none; /* 호버 시 버튼의 움직임을 없앰 */
  }

  &:focus {
    outline: none; /* 포커스 효과 제거 */
  }
`;

export default DetailMyQuestion;