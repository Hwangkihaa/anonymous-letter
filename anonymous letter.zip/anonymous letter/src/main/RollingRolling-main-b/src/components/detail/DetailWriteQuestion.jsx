import React from 'react';
import styled from 'styled-components';
import Button from '../elements/Button';
import { useState } from 'react';
import { useRef } from 'react';
import Cookies from 'js-cookie';
import { TbTrash } from 'react-icons/tb';
import {
  addQuestion,
  deleteQuestion,
  editQuestion,
  getPostList,
} from '../../util/api/detailList';
import { useParams } from 'react-router-dom';
import { useNavigate } from 'react-router-dom';
import { useQuery, useQueryClient, useMutation } from 'react-query';
import { FcUnlock, FcLock } from 'react-icons/fc';
import QuestionBoxs from './components/QuestionBoxs';
import FriendAudio from '../../audio/friend.jsx'
import StudyImage from '../../style/img/star.png';

function DetailWriteQuestion(){
  const [question, setQuestion] = useState('');
  const [isChecked, setIsChecked] = useState(false);
  const handleCheckboxChange = (event) => {
    setIsChecked(event.target.checked);
  };
  const anonymous = useRef();
  const param = useParams();
  const token = Cookies.get('accessJWTToken');

  // GET 데이터 불러옴
  const { data } = useQuery('getPost', () =>
    getPostList({ id: param.id, token })
  );

  const changeContent = (e) => {
    setQuestion(e.target.value);
  };
  const queryClient = useQueryClient();
  //POST 데이터 추가
  const muation = useMutation(addQuestion, {
    onSuccess: () => {
      queryClient.invalidateQueries('getPost');
    },
  });

  const deleteMutation = useMutation(deleteQuestion, {
    onSuccess: () => {
      console.log('삭제 성공');
      queryClient.invalidateQueries('getPost');
    },
  });

  const submitPostContent = (e) => {
    e.preventDefault();
    if (question !== '') {
      const form = {
        content: question,
        anonymous: anonymous.current.checked,
      };
      muation.mutate({ id: param.id, token: token, content: form });
      setQuestion('');
      anonymous.current.checked = false;
    }
  };

  const onDeleteHandler = (postid) => {
    const confirmText = window.confirm('정말로 삭제하시겠습니까?');
    if (confirmText) {
      deleteMutation.mutate({ id: postid, token: token });
    } else {
      return;
    }

    // console.log(postid);
  };

  //수정

  const [editInput, setEditInput] = useState('');

  const changeQuestion = (e) => {
    setEditInput(e.target.value);
  };

  const editMutation = useMutation(editQuestion, {
    onSuccess: () => {
      alert('수정완료');
      queryClient.invalidateQueries('getPost');
    },
  });

  const onEditHandler = (postid) => {
    editMutation.mutate({ id: postid, token: token, content: editInput });
  };

  // 수정과 관련된 기능 객체
  const editHandlerProps = {
    editInputValue: editInput,
    setEditInputValue: setEditInput,
    editInputChangeHandler: changeQuestion,
    editSubmitHandler: onEditHandler,
  };

  const navigate = useNavigate();

      function handleClick(){
        navigate('/home/letterstudy');
      }

  return (
    <WriteQuestionContainer>
      <QuestionFormContainer onSubmit={submitPostContent}>
        <FriendAudioContainer>
            <FriendAudio />
        </FriendAudioContainer>
      <ButtonContainer>
        <StyledButton onClick={handleClick}>
          <img src={StudyImage} alt="편지 작성 도움말" />
        </StyledButton>
      </ButtonContainer>
        <label>
          <NicknameSpan>{data.user.nickname}</NicknameSpan>님에게 질문하기
        </label>
        <textarea name="content" value={question} onChange={changeContent} />
        <QuestionSubmitContainer>
          <input
            type="checkbox"
            ref={anonymous}
            id={'anonymous'}
            checked={isChecked}
            onChange={handleCheckboxChange}
          />
          {/* <lable style={{ paddingRight: '5px' }}>익명으로 작성</lable> */}
          <label htmlFor={'anonymous'} aria-label={isChecked ? "익명으로 작성" : "익명으로 작성 해제"}>
                      {isChecked ? <FcLock fill="tomato" aria-hidden="true" /> : <FcUnlock aria-hidden="true" />}
          </label>

          <Button w={'60px'} bg={'#85C3C7'} color={'black'}>
            확인
          </Button>
        </QuestionSubmitContainer>
      </QuestionFormContainer>
      <QuestionContainer>
        {data.upperPost.length !== 0 && (
          <label>
            <NicknameSpan>내가</NicknameSpan> 남긴 질문
          </label>
        )}
        {data?.upperPost.map((item, i) => (
          <QuestionBoxs
            key={i}
            nickname={item.nickname}
            content={item.content}
            date={item.createdAt}
            comment={item.commentResponseDto}
            postId={item.postId}
            edit={editHandlerProps}
          >
            {!item.commentResponseDto && (
              <QuestionDelete onClick={() => onDeleteHandler(item.postId)}>
                <TbTrash />
              </QuestionDelete>
            )}
          </QuestionBoxs>
        ))}
      </QuestionContainer>

      <QuestionContainer>
        {data.bottomPost.content.length !== 0 ? (
          <label>
            <NicknameSpan>{data.user.nickname}</NicknameSpan>님에게 작성된 질문
          </label>
        ) : (
          <label>
            <EmptyQuestion>
              다른 사람이<NicknameSpan> {data.user.nickname} </NicknameSpan>
              님에게 질문을 작성하지 않았어요
            </EmptyQuestion>
          </label>
        )}
        {data?.bottomPost.content.map((item, i) => (
          <QuestionBoxs
            key={i}
            nickname={item.nickname}
            content={item.content}
            date={item.createdAt}
            postId={item.postId}
            comment={item.commentResponseDto}
          />
        ))}
      </QuestionContainer>
    </WriteQuestionContainer>
  );
}

const FriendAudioContainer = styled.div`
  position: fixed;
  top: 125px;
  right: 180px;
`;

const QuestionDelete = styled.span`
  margin-left: auto;
  margin-top: 2px;
  font-size: ${(props) => props.theme.FS.m};
  cursor: pointer;
`;

export const WriteQuestionContainer = styled.div`
  background-color: ${(props) => props.theme.CL.brandColorLight};
  border-radius: 30px;
`;

export const NicknameSpan = styled.span`
  color: #ffffff;
  padding-left: 0.3125rem;
`;

export const QuestionContainer = styled.div`
  ${(props) => props.theme.FlexCol};
  padding: 1.25rem;

  label {
    width: 100%;
    margin-bottom: 1rem;
    font-size: ${(props) => props.theme.FS.l};
    font-weight: bold;
    color: ${(props) => props.theme.CL.brandColorW};
  }
  textarea {
    width: 100%;
    min-height: 1.25rem;
    padding: 1.25rem;
    border: none;
    border-radius: 30px;
    font-size: ${(props) => props.theme.FS.m};
    resize: none;
    &:focus {
      outline: 2px solid ${(props) => props.theme.CL.brandColor};
    }
  }
`;

const QuestionFormContainer = styled(QuestionContainer.withComponent('form'))``;

export const EmptyQuestion = styled.div`
  ${(props) => props.theme.FlexRow};
`;
const QuestionSubmitContainer = styled.div`
  ${(props) => props.theme.FlexRow};
  justify-content: end;
  margin-top: 10px;

  > input {
    display: none;
  }
  input:checked + label,
  input + label:hover:not(input:checked + label) {
    animation: 4.72s infinite shake;
    @keyframes shake {
      0% {
        transform: translate(0, 0);
      }
      1.78571% {
        transform: translate(5px, 0);
      }
      3.57143% {
        transform: translate(0, 0);
      }
      5.35714% {
        transform: translate(5px, 0);
      }
      7.14286% {
        transform: translate(0, 0);
      }
      8.92857% {
        transform: translate(5px, 0);
      }
      10.71429% {
        transform: translate(0, 0);
      }
      100% {
        transform: translate(0, 0);
      }
    }
  }
  > label {
    width: auto;
    font-size: ${(props) => props.theme.FS.m};
    margin: 4px 10px 0 0;
    svg {
      font-size: ${(props) => props.theme.FS.xl};
    }
  }
`;

// 버튼 컨테이너 스타일
const ButtonContainer = styled.div`
  position: absolute;
  bottom: 20px; /* 하단 여백 설정 */
  right: 10px; /* 오른쪽 여백 설정 */
`;

// 스타일링된 버튼
const StyledButton = styled(Button)`
  padding: 20px; /* 버튼 안의 패딩 */
  display: flex;
  align-items: center;
  justify-content: center;
  cursor: pointer; /* 마우스 커서를 포인터로 변경 */
  background-color: transparent; /* 배경색을 투명하게 설정 */
  border: none; /* 테두리 제거 */
  transform: none; /* 호버 시 버튼의 움직임을 없앰 */

  img {
    width: 60px; /* 이미지 너비 */
    height: 60px; /* 이미지 높이 */
  }

  &:hover {
    transform: none; /* 호버 시 버튼의 움직임을 없앰 */
  }

  &:focus {
    outline: none; /* 포커스 효과 제거 */
  }
`;

export default DetailWriteQuestion;