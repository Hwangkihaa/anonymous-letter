import React, { useState, useEffect } from 'react';
import styled from 'styled-components';
import { CSSTransition } from 'react-transition-group';
import { useBgAnimation } from '../../hooks/useBgAnimation';
import ex1 from '../../style/img/ex1.jpg';
import ex2 from '../../style/img/ex2.jpg';
import HomeAnswerStudy from '../../pages/HomeAnswerStudy'; // 경로를 올바르게 설정

export default function HomeAnswerStudyLayout() {
  const [backgrounds, setBackgrounds] = useState([ex1, ex2]);

  useEffect(() => {
    const shuffledBackgrounds = shuffleArray(backgrounds);
    setBackgrounds(shuffledBackgrounds);
  }, []);

  const backgroundIndex = useBgAnimation(backgrounds);

  return (
    <LayoutWrapper>
      {backgrounds.map((url, index) => (
        <CSSTransition
          key={index}
          in={backgroundIndex === index}
          timeout={5000}
          classNames="fade"
          unmountOnExit
        >
          <Background bg={url} />
        </CSSTransition>
      ))}

      <ContentWrapper>
        <HomeAnswerStudy />
      </ContentWrapper>
    </LayoutWrapper>
  );
}

const LayoutWrapper = styled.div`
  ${(props) => props.theme.FlexCol}
  width: 100vw;
  height: 100vh;
  overflow: hidden; /* 배경 이미지가 넘칠 경우를 대비해 overflow를 hidden으로 설정 */

  /* 여백을 제거합니다. */
  margin: 0;
  padding: 0;
`;

const Background = styled.div`
  width: 100%;
  height: 100%;
  background: url(${(props) => props.bg});
  background-repeat: no-repeat;
  background-size: cover;
  background-position: center center;
  background-attachment: fixed;
  position: absolute;
  top: 0;
  left: 0;
`;

const ContentWrapper = styled.div`
  position: relative;
  z-index: 2;
  width: 100%;
  height: 100%;
`;

function shuffleArray(array) {
  const shuffled = [...array];
  for (let i = shuffled.length - 1; i > 0; i--) {
    const j = Math.floor(Math.random() * (i + 1));
    [shuffled[i], shuffled[j]] = [shuffled[j], shuffled[i]];
  }
  return shuffled;
}