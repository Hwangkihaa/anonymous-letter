import React, { useState, useEffect, useRef } from 'react';
import styled from 'styled-components';
import { CSSTransition } from 'react-transition-group';
import { useBgAnimation } from '../../hooks/useBgAnimation';
import logo from '../../style/img/logo.svg';    // 좌측 상단 롤링롤링 이미지 사용하지 않을 것이므로 주석처리 추후에 삭제 예정
import { Link, useNavigate } from 'react-router-dom';
import { LoginTokenCheck } from '../../hooks/useTokenCheck';
// 예시 배경 이미지 ex1과 ex2 import
import ex1 from '../../style/img/ex1.jpg';
import ex2 from '../../style/img/ex2.jpg';

export default function MainBgLayout(props) {
  const [backgrounds, setBackgrounds] = useState([ex1, ex2]);
  const [ariaMessage, setAriaMessage] = useState('');
  const navigate = useNavigate();
  LoginTokenCheck(navigate);

  useEffect(() => {
    const shuffledBackgrounds = shuffleArray(backgrounds);
    setBackgrounds(shuffledBackgrounds);
  }, []);

  const backgroundIndex = useBgAnimation(backgrounds);
  const messageCounter = useRef(0);

  // 배경 이미지 클릭 시 스크린 리더를 위한 메시지 설정
  const handleBackgroundClick = () => {
    messageCounter.current += 1;
    setAriaMessage(`F2를 누르시면 음성으로 설명을 들으실 수 있어요. ${messageCounter.current}`);
  };

  return (
    <WelcomeTitleWrapper>
      {backgrounds.map((url, index) => (
        <CSSTransition
          key={index}
          in={backgroundIndex === index}
          timeout={5000}
          classNames="fade"
          unmountOnExit
        >
          <Background bg={url} onClick={handleBackgroundClick} />
        </CSSTransition>
      ))}

      <WelcomeLogoContainer>
        <Link to="/">
          <LogoImg src={logo} alt="로고입니다. F2를 누르시면 음성으로 설명을 들으실 수 있어요." />
        </Link>
      </WelcomeLogoContainer>

      {props.children}

      <AriaLive role="status" aria-live="polite">
        {ariaMessage}
      </AriaLive>
    </WelcomeTitleWrapper>
  );
}
const WelcomeTitleWrapper = styled.div`
  ${(props) => props.theme.FlexCol}
  width: 100vw;
  height: 100vh;
  position: relative;

  .fade-enter {
    opacity: 0;
  }

  .fade-enter-active {
    opacity: 1;
    transition: opacity 3s ease-in-out;
  }

  .fade-exit {
    opacity: 1;
  }

  .fade-exit-active {
    opacity: 0;
    transition: opacity 3s ease-in-out;
  }
`;

const WelcomeLogoContainer = styled.div`
  position: absolute;
  top: 2%;
  left: 2%;
`;

const LogoImg = styled.img`
  height: 70px;
  display: block;
  filter: drop-shadow(0 0 2px black);
`;

const Background = styled.div`
  width: 100%;
  height: 100%;
  background: url(${(props) => props.bg});
  background-repeat: no-repeat;
  background-size: cover;
  background-position: center center;
  background-attachment: fixed;
  position: absolute;
`;

const AriaLive = styled.div`
  position: absolute;
  width: 1px;
  height: 1px;
  margin: -1px;
  border: 0;
  padding: 0;
  overflow: hidden;
  clip: rect(0, 0, 0, 0);
  white-space: nowrap;
`;

function shuffleArray(array) {
  const shuffled = [...array];
  for (let i = shuffled.length - 1; i > 0; i--) {
    const j = Math.floor(Math.random() * (i + 1));
    [shuffled[i], shuffled[j]] = [shuffled[j], shuffled[i]];
  }
  return shuffled;
}