import React from 'react';
import ReactTypingEffect from 'react-typing-effect';
import styled from 'styled-components';
//npm i react-typing-effect
/*
const TypingTitle = styled.p`

`;
 */
const TypingTitle = styled.h1`
  text-shadow: 2px 2px 6px black;
  
  bottom: 100px;
`;

export default function MainTyping() {
  return (
    <>
      <ReactTypingEffect
        text={['글월','편지에 눌러 담는 진심']}
        cursorRenderer={(cursor) => <h1>{cursor}</h1>}
        speed={300}
        eraseSpeed={100}
        eraseDelay={1500}
        typingDelay={1000}
        displayTextRenderer={(text, i) => {
          return (
            <TypingTitle>
              {text.split('').map((char, i) => {
                const key = `${i}`;
                return <span key={key}>{char}</span>;
              })}
            </TypingTitle>
          );
        }}
      />
    </>
  );
}

