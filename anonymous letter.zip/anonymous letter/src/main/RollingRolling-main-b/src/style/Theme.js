import styled, { css } from 'styled-components';
import scissors from '../style/img/scissors.png';

export const FlexRow = css`
  display: flex;
  flex-direction: row;
  justify-content: center;
  align-items: center;
  width: 100%;
`;

export const FlexRowBetween = css`
  display: flex;
  flex-direction: row;
  justify-content: space-between;
  align-items: center;
  width: 100%;
`;

export const FlexCol = css`
  display: flex;
  flex-direction: column;
  justify-content: center;
  align-items: center;
  width: 100%;
`;

export const DarkBlur = css`
  background: #161616aa;
  backdrop-filter: blur(3px);
`;

export const CL = {
  brandColor: '#85C3C7', // 테두리 및 사진 위 닉네임, 스프링, 스크롤, 답변창
  brandColorW: '#000000', // 본문 색깔
  scroll: '#85C3C7', // 진한 노랑
  brandColorLight: '#9be4e8', // 자기소개배경 및 질문하기 배경
  brandColorWe: '#caf9fc', // 연한 노랑
  brandColorWhite: '#4287f5',
};

export const FS = {
  xl: '1.8rem', // header
  l: '1.4rem', // title
  m: '1.1rem', // content, inputs
  s: '0.9rem', // button
  xs: '0.8rem', // message
};

export const Shadow = {
  all: 'rgb(0 0 0 / 0%) 0 0 0 0, rgb(0 0 0 / 0%) 0 0 0 0, rgb(0 0 0 / 30%) 0 20px 25px -5px, rgb(0 0 0 / 20%) 0 8px 10px -6px',
  bottom:
    'rgb(0 0 0 / 0%) 0 0 0 0, rgb(0 0 0 / 0%) 0 0 0 0, rgb(0 0 0 / 52%) 0 23px 34px -9px, rgb(0 0 0 / 14%) 0 11px 14px 3px',
};
export const CustomHr = styled.hr`
  opacity: 1;
  border: 0;
  clear: both;
  display: block;
  margin: 4rem 0;
  text-align: center;
  width: 100%;
  font-size: inherit;
  background: 0 0;
  border-bottom: 4px dashed #c8c8c8c2;
  height: 0;
  :before {
    content: '';
    background-image: url(${scissors});
    background-size: cover;
    display: block;
    width: 25px;
    height: 25px;
    position: absolute;
    margin-top: -10px;
    left: 64px;
  }
`;
