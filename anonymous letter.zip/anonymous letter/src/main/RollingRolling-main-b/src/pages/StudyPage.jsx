import React from 'react';
import styled from 'styled-components';
import Button from '../components/elements/Button';
import { useNavigate } from 'react-router-dom';


export default function StudyPage() {
  const navigate = useNavigate();

  return (
    <StudyContainer>
        <BasicBtnContainer>
            <Button defaultBorder onClick={() => navigate('/')}>기본화면으로 돌아가기</Button>
        </BasicBtnContainer>
            <StudyBtnContainer>

                <Button defaultBorder onClick={() => navigate('/basicstudy')}>1. 기본화면 사용법</Button>
                <Button defaultBorder onClick={() => navigate('/loginstudy')}>2. 로그인, 회원가입 방법</Button>
                <Button defaultBorder onClick={() => navigate('/friendstudy')}>3. 친구 검색, 편지함 들어가는 방법</Button>
                <Button defaultBorder onClick={() => navigate('/letterstudy')}>4. 친구에게 편지 작성하는 방법</Button>
                <Button defaultBorder onClick={() => navigate('/answerstudy')}>5. 질문에 답변하는 방법</Button>
                <Button defaultBorder onClick={() => navigate('/mypagestudy')}>6. 개인정보 수정 방법</Button>
            </StudyBtnContainer>
    </StudyContainer>
        );
}



const StudyContainer = styled.div`
  ${(props) => props.theme.FlexCol}
  width: 70%;
`;

const BasicBtnContainer = styled.div`
    margin-bottom: 7rem;
    position: relative;
    z-index: 1;
`;

const StudyBtnContainer = styled.div`
  margin-top: -5rem;
  position: relative;
  z-index: 1;
  display: flex;
  justify-content: flex-start;
  flex-direction: column;
  background: #ffffff76;
  backdrop-filter: blur(3px);
  padding: 3rem;
  border-radius: 1rem;
`;