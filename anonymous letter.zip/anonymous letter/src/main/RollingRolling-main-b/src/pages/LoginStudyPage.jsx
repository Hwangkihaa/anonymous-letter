import React from 'react';
import styled from 'styled-components';
import Button from '../components/elements/Button';
import { useNavigate, useLocation } from 'react-router-dom'; // useLocation 추가

export default function LoginStudyPage() {
  const navigate = useNavigate();
  const location = useLocation(); // useLocation 훅 사용

  function handleGoBack() {
    if (location.state && location.state.fromLogin) {
      navigate('/login', { state: { fromStudy: true } });
    } else if (location.state && location.state.fromSignup) {
      navigate('/signup', { state: { fromStudy: true } });
    } else {
      navigate('/study');
    }
  }

  return (
    <StudyContainer>
      <StudyBtnContainer>
        <Button defaultBorder onClick={handleGoBack}>
          목차로 돌아가기
        </Button>
      </StudyBtnContainer>
      <div
        style={{
          position: 'relative',
          paddingBottom: 'calc(45.260416666666664% + 41px)',
          height: 0,
          width: '100%',
        }}
      >
        <iframe
          src="https://demo.arcade.software/in340mq9sxcuJmeMMc3M?embed&show_copy_link=true"
          title="로그인 및 회원가입하기"
          frameBorder={0}
          loading="lazy"
          webkitallowfullscreen="true"
          mozallowfullscreen="true"
          allowFullScreen
          allow="clipboard-write"
          style={{
            position: 'absolute',
            top: 0,
            left: -70,
            width: '110%',
            height: '110%',
            colorScheme: 'light',
          }}
        />
      </div>
    </StudyContainer>
  );
}

const StudyContainer = styled.div`
  ${(props) => props.theme.FlexCol}
  width: 70%;
`;

const StudyBtnContainer = styled.div`
  margin-top: -5rem;
  position: relative;
  z-index: 1;
`;