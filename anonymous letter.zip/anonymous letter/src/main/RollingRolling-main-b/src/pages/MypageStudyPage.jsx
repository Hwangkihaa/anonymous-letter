import React from 'react';
import styled from 'styled-components';
import Button from '../components/elements/Button';
import { useNavigate } from 'react-router-dom';


export default function MypageStudyPage() {
  const navigate = useNavigate();

  return (
    <StudyContainer>
            <StudyBtnContainer>
                <Button defaultBorder onClick={() => navigate('/study')}>목차로 돌아가기</Button>
            </StudyBtnContainer>
            <div style={{position: 'relative', paddingBottom: 'calc(45.27777777777778% + 41px)', height: 0, width: '100%'}}><iframe src="https://demo.arcade.software/Lqgnomou6KJf5grKpK3D?embed&show_copy_link=true" title="마이페이지 개인정보 수정 방법" frameBorder={0} loading="lazy" webkitallowfullscreen mozallowfullscreen allowFullScreen allow="clipboard-write" style={{position: 'absolute', top: 0, left: -70, width: '110%', height: '110%', colorScheme: 'light'}} /></div>
    </StudyContainer>
        );
}



const StudyContainer = styled.div`
  ${(props) => props.theme.FlexCol}
  width: 70%;
`;

const StudyBtnContainer = styled.div`
  margin-top: -5rem;
  position: relative;
  z-index: 1;

`;