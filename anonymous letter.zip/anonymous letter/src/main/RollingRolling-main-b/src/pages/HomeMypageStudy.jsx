import React from 'react';
import styled from 'styled-components';
import Button from '../components/elements/Button';
import { useNavigate } from 'react-router-dom';

export default function HomeMypageStudy() {
  const navigate = useNavigate();

  const onCancel = () => {
          navigate(-1);
  }

  return (
    <StudyContainer>
      <StudyBtnContainer>
        <Button defaultBorder onClick={onCancel}>내 편지함으로 돌아가기</Button>
      </StudyBtnContainer>
      <IframeContainer>
        <iframe
          src="https://demo.arcade.software/Lqgnomou6KJf5grKpK3D?embed&show_copy_link=true"
          title="마이페이지 개인정보 수정 방법"
          frameBorder={0}
          loading="lazy"
          webkitallowfullscreen
          mozallowfullscreen
          allowFullScreen
          allow="clipboard-write"
        />
      </IframeContainer>
    </StudyContainer>
  );
}

const StudyContainer = styled.div`
  display: flex;
  flex-direction: column;
  align-items: center;
  justify-content: center;
  width: 100%;
  height: 100%;
  padding-top: 1rem; /* 필요한 경우 여백 조정 */
  margin: 0 auto; /* 중앙 정렬 */
  position: relative;
  z-index: 2;
`;

const StudyBtnContainer = styled.div`
  margin-bottom: 1rem; /* 버튼 위아래 여백 */
  position: relative;
  z-index: 1;
`;

const IframeContainer = styled.div`
  width: 95%;
  max-width: 1400px; /* 최대 너비 설정 */
  height: 90%; /* 부모 컨테이너 높이의 80% */
  position: relative;
  overflow: hidden;

  iframe {
    width: 100%;
    height: 100%;
    border: none;
  }
`;