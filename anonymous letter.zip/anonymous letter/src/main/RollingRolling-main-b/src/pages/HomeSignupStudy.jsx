import React from 'react';
import styled from 'styled-components';
import Button from '../components/elements/Button';
import { useNavigate } from 'react-router-dom';

export default function HomeSignupStudy() {
  const navigate = useNavigate();

  const onCancel = () => {
          navigate(-1);
  }

  return (
    <StudyContainer>
      <StudyBtnContainer>
        <Button defaultBorder onClick={onCancel}>회원가입 화면으로 돌아가기</Button>
      </StudyBtnContainer>
      <IframeContainer>
        <iframe
          src="https://demo.arcade.software/in340mq9sxcuJmeMMc3M?embed&show_copy_link=true"
          title="로그인 및 회원가입하기"
          frameBorder={0}
          loading="lazy"
          webkitallowfullscreen
          mozallowfullscreen
          allowFullScreen
          allow="clipboard-write"
        />
      </IframeContainer>
    </StudyContainer>
  );
}

const StudyContainer = styled.div`
  ${(props) => props.theme.FlexCol}
  width: 70%;
  padding-top: 1rem; /* 필요한 경우 여백 조정 */
  margin: 0 auto; /* 중앙 정렬 */
`;

const StudyBtnContainer = styled.div`
  margin-top: 2rem; /* 여백을 줄이기 위해 margin-top 값을 변경 */
  position: relative;
  z-index: 1;
`;

const IframeContainer = styled.div`
  position: relative;
  padding-bottom: calc(45.27777777777778% + 41px);
  height: 0;
  width: 100%;

  iframe {
    position: absolute;
    top: 0;
    left: -70px;
    width: 110%;
    height: 110%;
    color-scheme: light;
  }
`;