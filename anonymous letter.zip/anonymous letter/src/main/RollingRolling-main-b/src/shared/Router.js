import React from 'react';
import { BrowserRouter, Route, Routes } from 'react-router-dom';
import WelcomePage from '../pages/WelcomePage';
import StudyPage from '../pages/StudyPage';
import BasicStudyPage from '../pages/BasicStudyPage';
import LoginStudyPage from '../pages/LoginStudyPage';
import FriendStudyPage from '../pages/FriendStudyPage';
import LetterStudyPage from '../pages/LetterStudyPage';
import AnswerStudyPage from '../pages/AnswerStudyPage';
import MypageStudyPage from '../pages/MypageStudyPage';
import HomeLoginStudyLayout from '../components/layout/HomeLoginStudyLayout';
import HomeSignupStudyLayout from '../components/layout/HomeSignupStudyLayout';
import HomeFriendStudyLayout from '../components/layout/HomeFriendStudyLayout';
import HomeAnswerStudyLayout from '../components/layout/HomeAnswerStudyLayout';
import HomeLetterStudyLayout from '../components/layout/HomeLetterStudyLayout';
import HomeMypageStudyLayout from '../components/layout/HomeMypageStudyLayout';
import LoginPage from '../pages/LoginPage';
import SignupPage from '../pages/SignupPage';
import HomePage from '../pages/HomePage';
import DetailPage from '../pages/DetailPage';
import Layout from '../components/layout/Layout';
import MainBgLayout from '../components/layout/MainBgLayout';

const Router = () => {
  return (
    <BrowserRouter>
      <Routes>
        <Route path="/" element={<MainBgLayout><WelcomePage /></MainBgLayout>} />
        <Route path="study" element={<MainBgLayout><StudyPage /></MainBgLayout>} />
        <Route path="basicstudy" element={<MainBgLayout><BasicStudyPage /></MainBgLayout>} />
        <Route path="loginstudy" element={<MainBgLayout><LoginStudyPage /></MainBgLayout>} />
        <Route path="friendstudy" element={<MainBgLayout><FriendStudyPage /></MainBgLayout>} />
        <Route path="letterstudy" element={<MainBgLayout><LetterStudyPage /></MainBgLayout>} />
        <Route path="answerstudy" element={<MainBgLayout><AnswerStudyPage /></MainBgLayout>} />
        <Route path="mypagestudy" element={<MainBgLayout><MypageStudyPage /></MainBgLayout>} />
        <Route path="login" element={<MainBgLayout><LoginPage /></MainBgLayout>} />
        <Route path="signup" element={<MainBgLayout><SignupPage /></MainBgLayout>} />
        <Route path="home" element={<Layout><HomePage /></Layout>} />
        <Route path="home/:id" element={<Layout><DetailPage /></Layout>} />
        <Route path="/homeloginstudy" element={<HomeLoginStudyLayout />} />
        <Route path="/homesignupstudy" element={<HomeSignupStudyLayout />} />
        <Route path="home/friendstudy" element={<HomeFriendStudyLayout />} />
        <Route path="home/answerstudy" element={<HomeAnswerStudyLayout />} />
        <Route path="home/letterstudy" element={<HomeLetterStudyLayout />} />
        <Route path="home/mypagestudy" element={<HomeMypageStudyLayout />} />
      </Routes>
    </BrowserRouter>
  );
};

export default Router;