package com.example.hanghaeworld.dto;

import lombok.Getter;

@Getter
public class UserSearchRequestDto {
//    private String input;
    private String searchType;
}
